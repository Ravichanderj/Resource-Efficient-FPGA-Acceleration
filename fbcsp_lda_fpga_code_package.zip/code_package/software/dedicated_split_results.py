# Dedicated per-subject 75/25 held-out accuracy — BCI Competition IV Dataset 2a
# FBCSP + LDA, 4-class motor imagery (left hand / right hand / feet / tongue)
#
# This is the exact methodology behind the paper's reported numbers:
#   - Subject A01 (hardware-validation subject): 91.3% held-out accuracy
#   - 9-subject dedicated-split mean: 69.0% (range 43.6-91.3%)
# as opposed to the separate 5-fold CV numbers (65.8% mean) reported elsewhere
# in the paper — both are legitimate, different evaluation protocols.
#
# Run top-to-bottom in Google Colab. Needs the *T.gdf training files for
# A01-A09 (see "Dataset" note at the bottom of this file for where to get them).

# ----------------------------------------------------------------- setup ---
!pip install -q mne
import mne
mne.set_log_level('ERROR')

import os
import warnings
warnings.filterwarnings('ignore')
import numpy as np
from scipy.signal import butter, filtfilt
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.feature_selection import mutual_info_classif
from sklearn.pipeline import Pipeline
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.model_selection import train_test_split
from mne.decoding import CSP

# --------------------------------------------------------- locate files ---
DATA_DIR = '/content'  # <-- point this at the folder holding A0*T.gdf

SUBJECTS = [f"A0{i}" for i in range(1, 10)]  # A01..A09
train_paths = {s: os.path.join(DATA_DIR, f"{s}T.gdf") for s in SUBJECTS}
available_train = {s: p for s, p in train_paths.items() if os.path.exists(p)}
print(f"Found {len(available_train)} training files:", list(available_train))

# ------------------------------------------------------------ epoching ----
CLASS_CODES = {'769': 0, '770': 1, '771': 2, '772': 3}
CLASS_NAMES = ['left_hand', 'right_hand', 'feet', 'tongue']


def load_training_epochs(gdf_path, tmin=0.5, tmax=2.5, l_freq=1., h_freq=40.):
    """Load a *T.gdf file -> (X, y, sfreq). Rejects trials flagged with event 1023."""
    raw = mne.io.read_raw_gdf(gdf_path, preload=True,
                               eog=['EOG-left', 'EOG-central', 'EOG-right'],
                               verbose='ERROR')
    raw.filter(l_freq, h_freq, fir_design='firwin', verbose='ERROR')

    events, event_id = mne.events_from_annotations(raw, verbose='ERROR')
    inv = {v: k for k, v in event_id.items()}
    events = events[np.argsort(events[:, 0])]

    code_1023 = event_id.get('1023', None)
    rejected_times = set(events[events[:, 2] == code_1023, 0]) if code_1023 is not None else set()

    trial_events = []
    for i, e in enumerate(events):
        code_str = inv[e[2]]
        if code_str in CLASS_CODES:
            j = i - 1
            start_time = None
            while j >= 0:
                if inv[events[j, 2]] == '768':
                    start_time = events[j, 0]
                    break
                j -= 1
            if not (start_time is not None and start_time in rejected_times):
                trial_events.append([e[0], 0, e[2]])

    trial_events = np.array(trial_events)
    picks = mne.pick_types(raw.info, eeg=True, eog=False)
    epochs = mne.Epochs(raw, trial_events,
                         event_id={k: event_id[k] for k in CLASS_CODES if k in event_id},
                         tmin=tmin, tmax=tmax, picks=picks, baseline=None,
                         preload=True, verbose='ERROR')

    y = np.array([CLASS_CODES[inv[c]] for c in epochs.events[:, 2]])
    X = epochs.get_data(copy=True)  # (n_trials, n_channels, n_times)
    return X, y, raw.info['sfreq']


# ------------------------------------------------------------- FBCSP ------
class FBCSP(BaseEstimator, TransformerMixin):
    def __init__(self, sfreq=250., bands=None, n_components=4, n_select=10, reg='ledoit_wolf'):
        self.sfreq = sfreq
        self.bands = bands or [(4, 8), (8, 12), (12, 16), (16, 20), (20, 24),
                                (24, 28), (28, 32), (32, 36), (36, 40)]
        self.n_components = n_components
        self.n_select = n_select
        self.reg = reg

    def _bandpass(self, X, lo, hi):
        nyq = self.sfreq / 2.
        b, a = butter(4, [lo / nyq, hi / nyq], btype='band')
        return filtfilt(b, a, X, axis=-1)

    def fit(self, X, y):
        self.csps_ = []
        feats = []
        for (lo, hi) in self.bands:
            Xb = self._bandpass(X, lo, hi)
            csp = CSP(n_components=self.n_components, reg=self.reg, log=True, norm_trace=False)
            feats.append(csp.fit_transform(Xb, y))
            self.csps_.append(csp)
        feats = np.concatenate(feats, axis=1)
        mi = mutual_info_classif(feats, y, random_state=0)
        self.select_idx_ = np.argsort(mi)[::-1][:self.n_select]
        return self

    def transform(self, X):
        feats = []
        for (lo, hi), csp in zip(self.bands, self.csps_):
            Xb = self._bandpass(X, lo, hi)
            feats.append(csp.transform(Xb))
        feats = np.concatenate(feats, axis=1)
        return feats[:, self.select_idx_]


def make_fbcsp_lda(sfreq=250., n_select=10):
    return Pipeline([
        ('FBCSP', FBCSP(sfreq=sfreq, n_select=n_select)),
        ('LDA', LinearDiscriminantAnalysis()),
    ])


# ----------------------------------------- dedicated 75/25 held-out split -
# This is the evaluation protocol that reproduces A01 = 91.3% at random_state=42:
# a single stratified 75% train / 25% test split per subject (not k-fold CV),
# fit on the 75%, scored once on the untouched 25%.
dedicated_split_results = {}

for s, path in available_train.items():
    X, y, sfreq = load_training_epochs(path)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )

    clf = make_fbcsp_lda(sfreq=sfreq)
    clf.fit(X_train, y_train)
    acc = clf.score(X_test, y_test)

    dedicated_split_results[s] = dict(
        accuracy=acc, n_train=len(y_train), n_test=len(y_test)
    )
    print(f"{s}: dedicated held-out accuracy = {acc:.3f}  "
          f"(train={len(y_train)}, test={len(y_test)})")

accs = [r['accuracy'] for r in dedicated_split_results.values()]
print(f"\nMean across {len(accs)} subjects: {np.mean(accs):.3f}  "
      f"(range {min(accs):.3f}-{max(accs):.3f})")

# -------------------------------------------------------------- Dataset ---
# BCI Competition IV, Dataset 2a (Brunner, Leeb, Muller-Putz, Schlogl,
# Pfurtscheller, Graz University of Technology, 2008):
#
#   Official description + competition page:
#     https://www.bbci.de/competition/iv/#dataset2a
#
#   GDF file download (the *.gdf files this script reads, hosted in the
#   BNCI Horizon 2020 data repository under dataset "001-2014"):
#     http://bnci-horizon-2020.eu/database/data-sets
#
#   Equivalent data via auto-download, no manual files needed (used
#   elsewhere in this project for the MOABB benchmark cross-check):
#     moabb.datasets.BNCI2014_001
#     https://moabb.neurotechx.com/docs/generated/moabb.datasets.BNCI2014_001.html
#
# Each subject has a *T.gdf (training, labeled) and *E.gdf (evaluation) file;
# only the *T.gdf files are used here since the *E.gdf true labels are
# withheld by the competition organizers.
