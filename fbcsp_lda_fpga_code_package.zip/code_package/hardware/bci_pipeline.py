"""
BCI Competition IV Dataset 2a - loading, epoching, FBCSP+LDA pipeline.
Tested against real uploaded subject files before being placed into the notebook.
"""
import warnings
warnings.filterwarnings('ignore')
import numpy as np
import mne
from sklearn.pipeline import Pipeline
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.model_selection import StratifiedKFold, cross_val_score
from mne.decoding import CSP

mne.set_log_level('ERROR')

CLASS_CODES = {'769': 0, '770': 1, '771': 2, '772': 3}  # left, right, feet, tongue
CLASS_NAMES = ['left_hand', 'right_hand', 'feet', 'tongue']


def load_training_epochs(gdf_path, tmin=0.5, tmax=2.5, l_freq=4., h_freq=38.):
    """Load a *T.gdf training file -> (X, y) with artifact-flagged trials dropped."""
    raw = mne.io.read_raw_gdf(gdf_path, preload=True, eog=['EOG-left', 'EOG-central', 'EOG-right'],
                               verbose='ERROR')
    raw.filter(l_freq, h_freq, fir_design='firwin', verbose='ERROR')

    events, event_id = mne.events_from_annotations(raw, verbose='ERROR')
    inv = {v: k for k, v in event_id.items()}
    order = np.argsort(events[:, 0])
    events = events[order]

    code_1023 = event_id.get('1023', None)
    rejected_times = set(events[events[:, 2] == code_1023, 0]) if code_1023 is not None else set()

    trial_events = []
    for i, e in enumerate(events):
        code_str = inv[e[2]]
        if code_str in CLASS_CODES:
            # walk back to find this trial's 768 start time (immediately preceding 768)
            j = i - 1
            start_time = None
            while j >= 0:
                if inv[events[j, 2]] == '768':
                    start_time = events[j, 0]
                    break
                j -= 1
            is_rejected = start_time in rejected_times if start_time is not None else False
            if not is_rejected:
                trial_events.append([e[0], 0, e[2]])

    trial_events = np.array(trial_events)
    picks = mne.pick_types(raw.info, eeg=True, eog=False)
    epochs = mne.Epochs(raw, trial_events, event_id={k: event_id[k] for k in CLASS_CODES if k in event_id},
                         tmin=tmin, tmax=tmax, picks=picks, baseline=None, preload=True, verbose='ERROR')

    y = np.array([CLASS_CODES[inv[c]] for c in epochs.events[:, 2]])
    X = epochs.get_data(copy=True)
    return X, y, raw.info['sfreq']


def build_fbcsp_lda(n_components=4):
    """Simple (single-band) CSP + LDA pipeline. For true filter-bank CSP, run this
    per sub-band and concatenate CSP features before LDA (done in the notebook)."""
    csp = CSP(n_components=n_components, reg='ledoit_wolf', log=True, norm_trace=False)
    lda = LinearDiscriminantAnalysis()
    return Pipeline([('CSP', csp), ('LDA', lda)])


if __name__ == '__main__':
    X, y, sfreq = load_training_epochs('/mnt/user-data/uploads/A01T.gdf')
    print('X shape', X.shape, 'y counts', np.bincount(y), 'sfreq', sfreq)

    clf = build_fbcsp_lda()
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    scores = cross_val_score(clf, X, y, cv=cv)
    print('A01T 5-fold CV accuracy: %.3f +/- %.3f' % (scores.mean(), scores.std()))
