// C testbench for Vitis HLS C-simulation / co-simulation.
// Feeds 20 REAL held-out FBCSP feature vectors from subject A01's evaluation
// split (lda_test_vectors.h) through the fixed-point kernel.
//
// PASS/FAIL is gated on agreement with TEST_EXPECTED_CLASS, which is the
// FLOAT64 MODEL'S OWN prediction for each vector -- i.e. this testbench
// answers "does the fixed-point hardware match the floating-point model,"
// which is the correct hardware-correctness question. It is gated
// deliberately NOT on TEST_TRUE_CLASS (ground truth): the trained LDA model
// itself is only ~91% accurate on this held-out set (that's an inherent
// property of a linear classifier on this subject's data, unrelated to this
// kernel), so a couple of these 20 real trials are cases the *model* gets
// wrong even in full double precision -- that is not a hardware defect, and
// gating pass/fail on ground truth would abort a correctly-working
// co-simulation over it. Both are printed below so you can see the
// distinction directly.
//
// Run inside a Vitis HLS project:
//   csim_design           (C simulation against this file)
//   csynth_design          (synthesis -> resource/timing report)
//   cosim_design           (RTL co-simulation using this same testbench)

#include <cstdio>
#include "lda_classify.h"
#include "lda_test_vectors.h"

int main() {
    int n_matches_model = 0;
    int n_matches_truth = 0;

    for (int t = 0; t < N_TEST_VECTORS; t++) {
        feat_t features[N_FEAT];
        for (int f = 0; f < N_FEAT; f++) {
            features[f] = TEST_FEATURES[t][f];
        }

        ap_uint<2> pred_class;
        acc_t scores[N_CLASS];
        lda_classify(features, pred_class, scores);

        bool matches_model = (pred_class == TEST_EXPECTED_CLASS[t]);
        bool matches_truth = (pred_class == TEST_TRUE_CLASS[t]);
        n_matches_model += matches_model ? 1 : 0;
        n_matches_truth += matches_truth ? 1 : 0;

        printf("vector %2d: float64_model=%d true_label=%d hw_predicted=%d  "
               "scores=[%f %f %f %f]  %s\n",
               t, TEST_EXPECTED_CLASS[t], TEST_TRUE_CLASS[t], (int)pred_class,
               (double)scores[0], (double)scores[1], (double)scores[2], (double)scores[3],
               matches_model ? "MATCHES MODEL" : "DIVERGES FROM MODEL");
    }

    printf("\n%d / %d hardware predictions matched the float64 model (this is the pass/fail gate)\n",
           n_matches_model, N_TEST_VECTORS);
    printf("%d / %d hardware predictions matched ground truth (reference only, expect ~91%%)\n",
           n_matches_truth, N_TEST_VECTORS);

    // Non-zero return fails csim/cosim in the Vitis HLS GUI/CLI. Gated on
    // model agreement, NOT ground truth -- see the block comment above.
    return (n_matches_model == N_TEST_VECTORS) ? 0 : 1;
}
