"""Bit-accurate emulation of the planned Vitis HLS fixed-point datapath,
used to pick a safe bit width before committing to RTL. Mirrors what
ap_fixed<W,I> would do: two's-complement wraparound, truncation (matches
ap_fixed's default AP_TRN/AP_WRAP; the real HLS kernel can switch to
AP_RND/AP_SAT if wraparound ever becomes a concern -- our range check below
confirms it doesn't need to)."""
import os
import numpy as np

d = np.load(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'lda_export_A01.npz'))
coef, intercept = d['coef'], d['intercept']
Ftr, ytr, Fte, yte = d['Ftr'], d['ytr'], d['Fte'], d['yte']


def to_fixed(x, w, i):
    """Quantize float array x to a signed fixed-point format with total
    width w bits and i integer bits (matches ap_fixed<w,i> semantics:
    truncate to the nearest representable value, wrap on overflow)."""
    frac_bits = w - i
    scale = 2 ** frac_bits
    q = np.floor(x * scale)  # truncation, same as ap_fixed default AP_TRN
    qmax = 2 ** (w - 1) - 1
    qmin = -2 ** (w - 1)
    wrapped = ((q - qmin) % (qmax - qmin + 1)) + qmin  # two's complement wrap
    overflow = np.sum((q > qmax) | (q < qmin))
    return wrapped / scale, overflow


def fixed_point_lda_predict(F, coef, intercept, w_feat, i_feat, w_coef, i_coef, w_acc, i_acc):
    Fq, of1 = to_fixed(F, w_feat, i_feat)
    Cq, of2 = to_fixed(coef, w_coef, i_coef)
    Bq, of3 = to_fixed(intercept, w_coef, i_coef)
    scores = Fq @ Cq.T + Bq  # (n_trials, n_classes) -- this sum is the accumulator
    scores_q, of4 = to_fixed(scores, w_acc, i_acc)
    preds = np.argmax(scores_q, axis=1)
    total_overflow = of1 + of2 + of3 + of4
    return preds, total_overflow


# float64 golden reference (what sklearn / the PS-side software effectively computes)
scores_ref = Fte @ coef.T + intercept
preds_ref = np.argmax(scores_ref, axis=1)
acc_ref = (preds_ref == yte).mean()
print(f"Float64 reference accuracy on held-out set: {acc_ref:.4f}")
print(f"Value ranges -> features: [{Fte.min():.3f}, {Fte.max():.3f}], "
      f"coef: [{coef.min():.3f}, {coef.max():.3f}], intercept: [{intercept.min():.3f}, {intercept.max():.3f}]")

print("\nBit-width sweep (feature/weight format -> accuracy vs float64, agreement with float, overflow count):")
print(f"{'format':<22} {'accuracy':<10} {'agree_with_float64':<20} {'overflow_events'}")
configs = [
    # (w_feat,i_feat, w_coef,i_coef, w_acc,i_acc), all signed Q(i).(w-i)
    (8, 4, 8, 4, 16, 8),
    (12, 5, 12, 5, 24, 10),
    (16, 6, 16, 6, 32, 12),
    (16, 5, 16, 5, 32, 12),
    (20, 6, 20, 6, 40, 13),
]
for (wf, ifb, wc, ic, wa, ia) in configs:
    preds, overflow = fixed_point_lda_predict(Fte, coef, intercept, wf, ifb, wc, ic, wa, ia)
    acc = (preds == yte).mean()
    agree = (preds == preds_ref).mean()
    label = f"feat<{wf},{ifb}>/acc<{wa},{ia}>"
    print(f"{label:<22} {acc:<10.4f} {agree:<20.4f} {overflow}")
