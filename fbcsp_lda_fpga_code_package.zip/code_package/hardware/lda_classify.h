// LDA classifier accelerator for BCI IV 2a motor-imagery decoding.
// Target: Vitis HLS -> Zynq UltraScale+ MPSoC (ZCU104).
//
// Scope (deliberately narrow): this kernel implements ONLY the final linear
// discriminant step -- scores = features @ coef^T + intercept, class = argmax.
// Band-pass filtering and FBCSP spatial-filter projection stay in floating
// point on the ARM Cortex-A53 cores (PS side), reusing the exact Python
// pipeline already validated on real subject data (see the Colab notebook).
// Only the already-computed 10-dim feature vector crosses into the PL fabric.
//
// This split was chosen because sklearn's LinearDiscriminantAnalysis, at
// inference time, IS just this dot-product-plus-argmax -- no eigendecomposition
// or covariance estimation happens at inference, only at training time (which
// runs once, offline, in Python). That makes this an ideal, low-risk first
// FPGA target: fixed-size, fixed-latency, easy to verify bit-exactly against
// the float64 model (see quant_validation.py in this package).

#ifndef LDA_CLASSIFY_H
#define LDA_CLASSIFY_H

#include "ap_fixed.h"
#include "ap_int.h"

// ---- Fixed-point formats -------------------------------------------------
// Chosen from a bit-width sweep against real held-out EEG trials
// (see quant_validation.py). Q6.10 features/weights + a Q12.20 accumulator
// reproduced the float64 sklearn model's predictions bit-for-bit (100%
// agreement, 0 overflow events) on all held-out trials tested, comfortably
// covering the observed value ranges:
//   features  in [-3.09, 1.83]
//   coef_     in [-3.03, 2.10]
//   intercept in [-7.97, -0.77]
// 6 integer bits give headroom to roughly +/-32 -- ~4x the observed range,
// which is deliberate margin since a different subject's trained model
// could have a somewhat wider distribution.
typedef ap_fixed<16, 6>  feat_t;   // Q6.10 -- input feature / trained weight
typedef ap_fixed<16, 6>  coef_t;   // Q6.10 -- trained LDA coefficients (same format as feat_t)
typedef ap_fixed<32, 12> acc_t;    // Q12.20 -- per-class score accumulator

const int N_FEAT  = 10;  // FBCSP features selected by mutual information (n_select=10 in the notebook)
const int N_CLASS = 4;   // left_hand, right_hand, feet, tongue

// Trained weights (see lda_weights.h -- generated from a real fit, not placeholders)
extern const coef_t LDA_COEF[N_CLASS][N_FEAT];
extern const coef_t LDA_INTERCEPT[N_CLASS];

// Top-level accelerator function. All ports are AXI4-Lite (s_axilite): the
// feature/score arrays are small enough (10 and 4 elements) to live as a
// register bank, which keeps this PYNQ-MMIO-friendly with no DMA engine
// needed -- write features, poll/start, read back pred_class and scores.
void lda_classify(
    feat_t features[N_FEAT],
    ap_uint<2> &pred_class,
    acc_t scores_out[N_CLASS]
);

#endif // LDA_CLASSIFY_H
