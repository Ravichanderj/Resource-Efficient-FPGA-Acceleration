"""Filter-Bank CSP (FBCSP) feature extractor, sklearn-compatible, no leakage
when used inside a cross_val_score / Pipeline (each fold refits CSP filters
and the mutual-information band selector only on the training fold)."""
import numpy as np
from scipy.signal import butter, filtfilt
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.feature_selection import mutual_info_classif
from mne.decoding import CSP


class FBCSP(BaseEstimator, TransformerMixin):
    def __init__(self, sfreq=250., bands=None, n_components=4, n_select=8, reg='ledoit_wolf'):
        self.sfreq = sfreq
        self.bands = bands or [(4, 8), (8, 12), (12, 16), (16, 20), (20, 24),
                                (24, 28), (28, 32), (32, 36), (36, 40)]
        self.n_components = n_components
        self.n_select = n_select
        self.reg = reg

    def _bandpass(self, X, lo, hi):
        nyq = self.sfreq / 2.
        b, a = butter(4, [lo / nyq, hi / nyq], btype='band')
        return filtfilt(b, a, X, axis=-1)

    def fit(self, X, y):
        self.csps_ = []
        feats = []
        for (lo, hi) in self.bands:
            Xb = self._bandpass(X, lo, hi)
            csp = CSP(n_components=self.n_components, reg=self.reg, log=True, norm_trace=False)
            f = csp.fit_transform(Xb, y)
            self.csps_.append(csp)
            feats.append(f)
        feats = np.concatenate(feats, axis=1)  # (n_trials, n_bands*n_components)
        mi = mutual_info_classif(feats, y, random_state=0)
        self.select_idx_ = np.argsort(mi)[::-1][:self.n_select]
        return self

    def transform(self, X):
        feats = []
        for (lo, hi), csp in zip(self.bands, self.csps_):
            Xb = self._bandpass(X, lo, hi)
            feats.append(csp.transform(Xb))
        feats = np.concatenate(feats, axis=1)
        return feats[:, self.select_idx_]
