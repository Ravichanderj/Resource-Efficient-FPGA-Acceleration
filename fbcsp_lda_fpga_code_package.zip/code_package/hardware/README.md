# FBCSP+LDA Motor-Imagery Classifier on ZCU104

> **Update, post-hardware-testing:** this package has been revised after a
> real Vitis HLS run surfaced two issues, both now fixed here:
> 1. `lda_test_vectors.h` originally checked the kernel's output against
>    *ground-truth* class labels. That's the wrong bar — the trained LDA
>    model itself is only ~91% accurate on held-out data (a property of the
>    model, not the hardware), so 2 of the 20 test vectors were cases the
>    *float64 model itself* gets "wrong." Checking against ground truth made
>    Co-simulation abort with a false failure even though the hardware was
>    working correctly. Fixed: the pass/fail gate now checks agreement with
>    the float64 model's own prediction (verified 20/20), with ground truth
>    kept alongside for reference only. If you pulled this package before
>    this note existed, replace your copies of `lda_test_vectors.h` and
>    `lda_tb.cpp` with the ones in this version.
> 2. **Separately, and still something you need to fix yourself:** double
>    check your Vitis/Vivado HLS project's target part. A real synthesis log
>    from this project showed `Setting target device to 'xc7vx485t-ffg1157-1'`
>    (a Virtex-7 part) on every run — not the ZCU104's `xczu7ev-ffvc1156-2-e`.
>    Any report generated while the wrong part is selected is not valid for
>    your board. Fix the part in Project/Solution Settings before trusting any
>    synthesis numbers.

A minimal, verified FPGA accelerator for the final linear-discriminant step
of the FBCSP+LDA pipeline built earlier for BCI Competition IV 2a. Scope, by
design: **only** `scores = features @ coef^T + intercept; class = argmax`
runs on the PL fabric. Band-pass filtering and CSP spatial-filter projection
stay in floating point on the ZCU104's ARM Cortex-A53 cores (PS), reusing the
exact `bci_pipeline.py` / `fbcsp.py` code from the Colab notebook unchanged.

**What's actually verified here, and how:** I don't have Vivado/Vitis in
this environment, so I could not run synthesis or C-simulation myself. What
I *did* verify, against your real uploaded EEG data:

- Fit a genuine FBCSP+LDA model on subject A01's training file, held out 25%
  of trials it never trained on.
- Built a bit-accurate Python emulation of the exact fixed-point arithmetic
  the HLS kernel performs (`quant_validation.py` — run it yourself, it's
  plain Python/NumPy, no Xilinx tools needed).
- Swept bit widths against that held-out data. Result: **Q6.10 features/
  weights with a Q12.20 accumulator reproduce the float64 model's
  predictions bit-for-bit on every held-out trial tested (100% agreement,
  0 overflow events)** — that's the format baked into `lda_classify.h`.
- The 20 test vectors in `lda_test_vectors.h` are real held-out feature
  vectors from that same split, not synthetic data.

What I could **not** verify: that `lda_classify.cpp` actually synthesizes
cleanly in your Vitis HLS version, meets timing, or that the PYNQ register
names in `pynq_driver.py` match what your build produces. Those steps need
your board and toolchain — the checklist below tells you exactly how to
confirm each one.

## Files in this package

| File | Purpose |
|---|---|
| `lda_classify.h` / `.cpp` | The HLS kernel (Vitis HLS C++, `ap_fixed` types, AXI4-Lite interface) |
| `lda_weights.h` | Real trained LDA weights (subject A01) baked in as constants |
| `lda_test_vectors.h` | Real held-out feature vectors + expected class, for the testbench |
| `lda_tb.cpp` | C testbench for Vitis HLS csim/cosim — expects 20/20 matches |
| `quant_validation.py` | **Runs today, no Xilinx tools.** Bit-width sweep against real data |
| `export_weights.py` | Regenerate the two headers for a different subject / `n_select` |
| `pynq_driver.py` | Python driver skeleton for calling the accelerator from PYNQ |
| `bci_pipeline.py`, `fbcsp.py` | The unchanged PS-side feature-extraction code from the notebook |
| `lda_export_A01.npz` | Cached model + features `quant_validation.py` reads |

## Step 1 — Confirm the quantization choice (no hardware needed)

```
pip install numpy scikit-learn mne scipy
python quant_validation.py
```

Expect the same output I got: 100% agreement with float64 at the Q6.10/
Q12.20 format, 0 overflow events. If you swap subjects or `n_select`, rerun
`export_weights.py` (see below) and re-check this before touching Vitis —
it's much faster to catch a bad bit-width choice here than after synthesis.

## Step 2 — Vitis HLS: simulate, synthesize, export IP

1. Create a new Vitis HLS component/project targeting the ZCU104's part —
   `xczu7ev-ffvc1156-2-e` (confirm against your exact ZCU104 revision in the
   Vivado board files; earlier ZCU104 revisions used `-1` speed grade).
2. Add `lda_classify.cpp` / `.h` / `lda_weights.h` as design files, `lda_tb.cpp`
   / `lda_test_vectors.h` as the testbench, set `lda_classify` as the top
   function.
3. Run **C Simulation**. Expect `20 / 20 test vectors matched` in the console
   — if any mismatch, it means Vitis HLS's fixed-point arithmetic diverged
   from the Python emulation (check the rounding/saturation mode Vitis
   defaulted to; the kernel assumes `AP_TRN`/`AP_WRAP`, the `ap_fixed`
   default, so this shouldn't happen, but confirm).
4. Run **C Synthesis**. This is where you get real numbers I could only
   estimate (see below) — check the resource summary (LUT/FF/DSP/BRAM) and
   the latency/II report.
5. Run **Co-simulation** (RTL-level, reusing the same testbench) to confirm
   the synthesized RTL still passes all 20 vectors — this catches anything
   synthesis changed that C simulation wouldn't.
6. **Export RTL** as a Vivado IP (`Export RTL` → `IP Catalog` format).

### Resource/timing expectations (estimate — confirm against your own report)

This kernel is 40 fixed-point multiply-accumulates (4 classes × 10 features)
plus a 4-way argmax, fully unrolled, 16/32-bit operands. Designs this size
typically land around a few hundred LUTs, under 10 DSP48 slices, negligible
BRAM (everything fits in registers), and single-digit-cycle latency once
pipelined — on the ZCU104's part this should be well under 1% of fabric
resources and, at a 100–200 MHz kernel clock, sub-microsecond compute
latency. In practice, the AXI-Lite round-trip from Python (MMIO writes/reads
through the PYNQ driver) will dominate end-to-end latency, not the kernel
itself — if low latency matters for your use case, that round-trip cost is
the thing worth profiling first, not the kernel.

## Step 3 — Vivado: block design and bitstream

1. Create a Vivado project targeting the **ZCU104 board** (use the board
   preset, not just the part, so the Zynq UltraScale+ MPSoC config and DDR/
   peripheral defaults match your board).
2. Add the exported IP to the project's IP repository, run **Block Automation**
   to instantiate the Zynq UltraScale+ MPSoC PS, then **Connect Automation**
   to wire one of the PS's general-purpose AXI master ports (e.g. `M_AXI_HPM0_FPD`)
   to the `lda_classify` IP's `s_axi_CTRL` AXI4-Lite slave port.
3. Give the IP instance a clear, memorable name (e.g. `lda_classify_0`) —
   you'll need it in the PYNQ driver.
4. Validate the design, generate the bitstream, then **File → Export → Export
   Hardware** with "Include bitstream" checked. This produces both the
   `.bit` and the `.hwh` metadata file PYNQ needs — keep them together.

## Step 4 — PYNQ: control it from Python/Jupyter

ZCU104 has an official PYNQ image. Boot it, copy your `.bit` + `.hwh` (same
base filename, e.g. `lda_classify_wrapper.bit` / `.hwh`) onto the board, then
in a Jupyter cell:

```python
from pynq import Overlay
ol = Overlay('lda_classify_wrapper.bit')
ip = ol.lda_classify_0          # must match the instance name from Step 3.3
print(ip.register_map)          # <-- run this first, it tells you the REAL field names
```

`register_map` is generated from the `.hwh` file and will show you the
actual AXI-Lite register names/offsets Vitis HLS assigned (commonly
`features_0`..`features_9`, `pred_class`, `scores_out_0`..`scores_out_3`,
plus a `CTRL` register with `AP_START`/`AP_DONE`/`AP_IDLE` bits — but confirm
against what actually prints, tool-version naming has changed over Vitis
releases). Update the `feature_fields` / `score_fields` / `pred_field` lists
in `pynq_driver.py` to match, then:

```python
from pynq_driver import LDAAccelerator
accel = LDAAccelerator('lda_classify_wrapper.bit')

# feature_vector: the 10-dim FBCSP output for one epoch, computed on the PS
# side with the SAME code as the notebook (bci_pipeline.py + fbcsp.py) --
# nothing about that Python code changes, only its output now feeds the PL.
pred_class, scores = accel.predict(feature_vector)
print(CLASS_NAMES[pred_class])
```

## Step 5 — Wire it into the existing feature-extraction pipeline

On the PS side (Python running on the ZCU104's ARM cores under PYNQ), reuse
`bci_pipeline.py`'s `load_training_epochs` / raw-signal filtering and
`fbcsp.py`'s `FBCSP` transformer exactly as in the Colab notebook — train the
`FBCSP` + `LinearDiscriminantAnalysis` in Python as before (or load a model
already fit on a workstation), but for each new trial, instead of calling
`lda.predict(...)`, call `fbcsp.transform(...)` to get the 10-dim feature
vector and pass that to `LDAAccelerator.predict(...)`. Everything upstream
of that call is identical to what you already have working.

## Extending this

- **Different subject / feature count:** `python export_weights.py --gdf
  /path/to/A0xT.gdf --subject A0x [--n-select N]` regenerates both headers
  and reruns the quantization check — rerun Step 1 before resynthesizing.
- **Full streaming pipeline on PL** (bandpass filter + CSP projection also in
  hardware, not just the classifier): a substantially larger effort — IIR
  filter design in fixed point, a 22×N-dim CSP projection matrix-multiply,
  and log-variance computation would all need their own HLS blocks upstream
  of this one. Worth doing only once this classifier-only design is working
  end-to-end and you've profiled whether PS-side feature extraction is
  actually your bottleneck.
- **EEGNet on the DPU:** a separate toolflow entirely (Vitis AI quantization
  + compilation targeting the ZCU104's DPU IP) — ask if you want this path
  scoped out next.
