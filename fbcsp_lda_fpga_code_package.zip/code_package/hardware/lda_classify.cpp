#include "lda_classify.h"
#include "lda_weights.h"  // defines LDA_COEF/LDA_INTERCEPT (extern-declared in lda_classify.h);
                           // included ONLY here so the array definitions exist in exactly one
                           // translation unit -- lda_tb.cpp never references them directly, it
                           // only calls lda_classify(), so no multiple-definition linker error.

void lda_classify(
    feat_t features[N_FEAT],
    ap_uint<2> &pred_class,
    acc_t scores_out[N_CLASS]
) {
    // All ports AXI4-Lite, bundled into one control/data interface -- small
    // enough (10 in, 1+4 out) that a DMA/AXI-Stream path would be overkill.
    // From Python (PYNQ) this becomes plain MMIO reads/writes; see the
    // integration guide for the driver class.
#pragma HLS INTERFACE s_axilite port=features   bundle=CTRL
#pragma HLS INTERFACE s_axilite port=pred_class bundle=CTRL
#pragma HLS INTERFACE s_axilite port=scores_out bundle=CTRL
#pragma HLS INTERFACE s_axilite port=return     bundle=CTRL

    acc_t scores[N_CLASS];

    // One discriminant score per class: dot(coef[c], features) + intercept[c].
    // N_FEAT=10 is small enough to fully unroll -- this becomes 40 parallel
    // fixed-point multiplies feeding 4 independent adder trees, so the whole
    // kernel should synthesize to a handful of DSP48 slices and complete in
    // a small, fixed number of cycles (see the timing estimate in README.md
    // -- confirm the exact number with your own Vitis HLS synthesis report).
    score_loop:
    for (int c = 0; c < N_CLASS; c++) {
#pragma HLS PIPELINE II=1
        acc_t sum = LDA_INTERCEPT[c];
        feat_loop:
        for (int f = 0; f < N_FEAT; f++) {
#pragma HLS UNROLL
            sum += (acc_t)(LDA_COEF[c][f] * features[f]);
        }
        scores[c] = sum;
    }

    // argmax over 4 classes
    acc_t best = scores[0];
    ap_uint<2> best_idx = 0;
    argmax_loop:
    for (int c = 1; c < N_CLASS; c++) {
        if (scores[c] > best) {
            best = scores[c];
            best_idx = (ap_uint<2>)c;
        }
    }

    pred_class = best_idx;
    output_loop:
    for (int c = 0; c < N_CLASS; c++) {
        scores_out[c] = scores[c];
    }
}
