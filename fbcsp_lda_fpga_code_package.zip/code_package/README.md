# Resource-Efficient FPGA Acceleration of FBCSP-LDA for Motor-Imagery EEG Classification

Code accompanying the manuscript "Resource-Efficient FPGA Acceleration of
FBCSP-LDA" (FBCSP + LDA motor-imagery EEG classifier, hardware-accelerated
on a Xilinx ZCU104 / Zynq UltraScale+).

## Repository structure

```
software/   Python pipeline: data loading, FBCSP feature extraction,
            LDA training/evaluation (runs on a workstation or Google Colab,
            no FPGA hardware needed)
hardware/   Vitis HLS kernel for the LDA classification step, its
            testbench, PYNQ driver, and the fixed-point quantization
            validation script
```

### `software/`

| File | Purpose |
|---|---|
| `BCI_IV_2a_Classification.ipynb` | End-to-end pipeline: GDF loading, epoching, FBCSP feature extraction, FBCSP+LDA training, 5-fold cross-validation, and an EEGNet (PyTorch) comparison baseline |
| `dedicated_split_results.py` | Dedicated per-subject 75/25 stratified held-out evaluation (`random_state=42`) — the protocol behind the paper's reported 91.3% (subject A01) and 69.0% 9-subject mean figures |

### `hardware/`

Vitis HLS implementation of the final linear-discriminant step
(`scores = features @ coef^T + intercept; class = argmax`) targeting the
ZCU104's `xczu7ev-ffvc1156-2-e` part. See `hardware/README.md` for the full
build/deploy walkthrough (quantization validation → HLS C-sim/synthesis/
co-sim → Vivado block design/bitstream → PYNQ deployment).

## Dataset

**BCI Competition IV, Dataset 2a** (Brunner, Leeb, Müller-Putz, Schlögl,
Pfurtscheller — Graz University of Technology, 2008). 9 subjects, 4-class
motor imagery (left hand / right hand / feet / tongue), 22 EEG + 3 EOG
channels at 250 Hz.

- Official description and competition page:
  https://www.bbci.de/competition/iv/#dataset2a
- GDF file download (BNCI Horizon 2020 data repository, dataset "001-2014"):
  http://bnci-horizon-2020.eu/database/data-sets
- Equivalent auto-download access via MOABB (no manual files needed):
  `moabb.datasets.BNCI2014_001` —
  https://moabb.neurotechx.com/docs/generated/moabb.datasets.BNCI2014_001.html

Only the `*T.gdf` (training) files are used; the `*E.gdf` evaluation files'
true labels are withheld by the competition organizers, so they cannot be
used for accuracy scoring.

## Reproducing the paper's headline numbers

1. Install dependencies: `pip install mne scikit-learn scipy numpy torch`
   (or run `software/BCI_IV_2a_Classification.ipynb` in Google Colab, which
   has everything except `mne` preinstalled).
2. Download the 9 subjects' `*T.gdf` files from either dataset link above
   and place them in one folder.
3. Run `software/BCI_IV_2a_Classification.ipynb` top-to-bottom for the
   5-fold cross-validation numbers (65.8% 9-subject mean).
4. Run `software/dedicated_split_results.py` (paste into one Colab cell, or
   run locally with the dependencies above) for the dedicated 75/25
   held-out numbers (91.3% subject A01, 69.0% 9-subject mean).
5. For the hardware results, follow `hardware/README.md` — this step
   requires Xilinx Vitis HLS / Vivado and a ZCU104 board (or equivalent
   Zynq UltraScale+ target) and is not reproducible from a workstation
   alone.

## License

Add a license file here before publishing this repository (e.g., MIT or
Apache-2.0 for the code) — journals generally require an explicit open
license on archived code, and GitHub will not show one by default.
